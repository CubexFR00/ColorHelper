﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Window
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.HTMLColorLabel = New System.Windows.Forms.Label()
        Me.HTMLColor = New System.Windows.Forms.TextBox()
        Me.JavaColor = New System.Windows.Forms.TextBox()
        Me.JavaColorLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'HTMLColorLabel
        '
        Me.HTMLColorLabel.AutoSize = True
        Me.HTMLColorLabel.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HTMLColorLabel.ForeColor = System.Drawing.Color.White
        Me.HTMLColorLabel.Location = New System.Drawing.Point(13, 18)
        Me.HTMLColorLabel.Name = "HTMLColorLabel"
        Me.HTMLColorLabel.Size = New System.Drawing.Size(161, 18)
        Me.HTMLColorLabel.TabIndex = 0
        Me.HTMLColorLabel.Text = "♦️ | HTML HEX COLOR:"
        '
        'HTMLColor
        '
        Me.HTMLColor.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HTMLColor.Location = New System.Drawing.Point(16, 43)
        Me.HTMLColor.MaxLength = 6
        Me.HTMLColor.Name = "HTMLColor"
        Me.HTMLColor.Size = New System.Drawing.Size(285, 25)
        Me.HTMLColor.TabIndex = 1
        Me.HTMLColor.Text = "FF00FF"
        '
        'JavaColor
        '
        Me.JavaColor.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.JavaColor.Location = New System.Drawing.Point(16, 123)
        Me.JavaColor.Name = "JavaColor"
        Me.JavaColor.Size = New System.Drawing.Size(285, 25)
        Me.JavaColor.TabIndex = 3
        Me.JavaColor.Text = "0xFFFF00FF"
        '
        'JavaColorLabel
        '
        Me.JavaColorLabel.AutoSize = True
        Me.JavaColorLabel.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.JavaColorLabel.ForeColor = System.Drawing.Color.White
        Me.JavaColorLabel.Location = New System.Drawing.Point(13, 98)
        Me.JavaColorLabel.Name = "JavaColorLabel"
        Me.JavaColorLabel.Size = New System.Drawing.Size(157, 18)
        Me.JavaColorLabel.TabIndex = 2
        Me.JavaColorLabel.Text = "♦️ | JAVA HEX COLOR:"
        '
        'Window
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(313, 175)
        Me.Controls.Add(Me.JavaColor)
        Me.Controls.Add(Me.JavaColorLabel)
        Me.Controls.Add(Me.HTMLColor)
        Me.Controls.Add(Me.HTMLColorLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Window"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Color Helper by CubexFR"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents HTMLColorLabel As System.Windows.Forms.Label
    Friend WithEvents HTMLColor As System.Windows.Forms.TextBox
    Friend WithEvents JavaColor As System.Windows.Forms.TextBox
    Friend WithEvents JavaColorLabel As System.Windows.Forms.Label

End Class
