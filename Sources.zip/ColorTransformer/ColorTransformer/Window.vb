﻿Public Class Window

    Private Sub TextBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles HTMLColor.KeyUp
        On Error Resume Next
        JavaColor.Text = "0xFF" & HTMLColor.Text.Replace("#", "").ToUpper
    End Sub

    Private Sub TextBox2_KeyUp(sender As Object, e As KeyEventArgs) Handles JavaColor.KeyUp
        On Error Resume Next
        HTMLColor.Text = JavaColor.Text.Substring(4)
    End Sub
End Class
